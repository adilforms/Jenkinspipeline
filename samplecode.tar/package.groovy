def zipWar(Map param= [:]){
    sh """
    zip -r "${param.artifactname}-${param.version}.war" "${param.path}"
    """
}