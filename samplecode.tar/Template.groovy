// List of parameters requires
// params.node
// params.buildtype eg:maven
// params.packagetype eg:zipWar
// params.name eg: artifactname
// params.filespath eg: ./dist/*
def call(Map params = [:]) {
    def datas
    pipeline {
        agent {
        node {
            label "${params.node}"
            customWorkspace "workspace/${env.JOB_NAME}/${BUILD_NUMBER}"
            }
        }
        environment {
            VERSION= "'sh(script: "date", returnStdout: true).toString().trim()'-${BUILD_NUMBER}"
        }
        stages {
            stage ("Build") {
        		steps{
        			build."${params.buildtype}"()
        		}
        		post {
        			always {
                        script{
                            println "Stage Result : ${currentBuild.result}" 
                        }
                    }
        		}
        	}
        	stage('package artifact') {
                when {
        			expression {
        				datas.package == true
        			}
        		}
        		steps {
                        package."${param.packagetype}"(name: "${params.name}", path: "${params.filespath}", version = "${VERSION}")
                        }
                post {
        			always {
                        script{
                            println "Stage Result : ${currentBuild.result}" 
                        }
                    }
        		}
            }
            stage('sonarscan') {
                when {
        			expression {
        				datas.sonarscan == true
        			}
        		}
                steps {
                    script{
                        echo 'Executing sonar scan'
                    }
                }
            }
           stage('Upload Artifact') {
        		when {
        			expression {
        				datas.artifactory.Upload == true
        			}
        		}
        		steps {
        			if [ ${env.BRANCH_NAME} = "release" ]
                    {
                        artifactory.release(artifactname: "${params.name}", version: "${VERSION}")
                    }
                    else
                    {
                         artifactory.dev(artifactname: "${params.name}", version: "${VERSION}")
                    }
                    
        		}
        		post {
        			always {
                        script{
                            println "Stage Result : ${currentBuild.result}" 
                        }
                    }
        		}
        	}
        }

   
