def maven(Map){
    sh '''
    mvn clean
    mvn package
    '''
}
def angular(Map){
    sh 'ng build --production'
}
